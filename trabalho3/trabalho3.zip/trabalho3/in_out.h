#include "estruturas.h"

void mostra_ajuda(char *name);
void saida(tipolista *lista_aux);
void le_cidades(FILE **fp, int *qnt);
int le_arestas(FILE **fp,int *i, int *x, int* p);
