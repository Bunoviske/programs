#include "in_out.h"

int verifica_vertices(tipolista vetor[], int n);
void montar_lista(tipolista *lista_aux,tipolista vetor[], int u);
void dfs_visit(tipolista *lista_aux,tipolista vetor[], int u, int n);
